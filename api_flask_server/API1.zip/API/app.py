from flask import Flask, render_template, request, jsonify
from flask_restful import Api, Resource, reqparse
from sql_queries import *

app = Flask(__name__)
api = Api(app)
def get_posts():
    conn = create_connection()
    post = execute_read_query(conn,
        query="""
        SELECT id, text, rating, url, type
        FROM posts
        ORDER BY likes DESC, rating DESC
        LIMIT 1;""")[0]
    conn.close()
    text = post[1]
    print(text)
    dict = {
        'id': post[0],
        'text': text,
        'url': post[3],
        'rating': post[2],
        'type': post[4],
    }
    return dict

def get_post(post_id):
    conn = create_connection()
    post = execute_read_query(conn,
        query="""
        SELECT id, text, rating, url, type
        FROM posts
        WHERE id = '%s';""" % post_id) [0]
    conn.close()
    text = post[1]
    # s_bytes = bytes(text)
    # text = s_bytes.decode("utf-8")
    print(text)
    dict = {
        'id': post[0],
        'text': text,
        'rating': post[2],
        'type': post[4],
    }
    return dict


class Quote(Resource):
    def get(self, id=''):
        if id == "":
            return get_posts()
        else:
            return get_post(id), 200


api.add_resource(Quote, "/index", "/index/", "/index/<id>")
if __name__ == '__main__':
    app.run(host='0.0.0.0')

